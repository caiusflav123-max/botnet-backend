# BOTNET Panel v3.0 — Deployment Guide

## Architecture

```
Netlify (index.html)
       ↓ HTTPS API calls
FastAPI Backend (Railway / Render / VPS)
       ↓ subprocess
Python Bot Processes
       ↓ Telegram API
Telegram Bots
```

---

## 1. Deploy the Backend

### Option A — Railway (Recommended, Free tier)

1. Create account at https://railway.app
2. New Project → Deploy from GitHub (push this folder to a repo first)
   OR: New Project → Empty → drag-drop this folder
3. Set environment variables in Railway dashboard:
   ```
   API_SECRET_KEY   = some-long-random-secret-string-here
   ADMIN_PASSWORD   = yourStrongPassword
   ALLOWED_ORIGINS  = https://your-site.netlify.app
   PORT             = 8000   (Railway sets this automatically)
   ```
4. Deploy. Railway gives you a URL like:
   `https://botnet-panel-production.up.railway.app`

### Option B — Render (Free tier, sleeps after inactivity)

1. Create account at https://render.com
2. New → Web Service → connect your GitHub repo
3. Build Command: `pip install -r requirements.txt`
4. Start Command: `uvicorn main:app --host 0.0.0.0 --port $PORT`
5. Set env vars (same as Railway above)
6. Deploy → get URL like `https://botnet-panel.onrender.com`

### Option C — VPS (DigitalOcean / Linode / Hetzner)

```bash
# SSH into your VPS
apt update && apt install python3-pip python3-venv -y

# Clone / upload your project
git clone https://your-repo.git /app/botnet
cd /app/botnet

# Install deps
pip3 install -r requirements.txt

# Set env vars
export API_SECRET_KEY="your-secret-key"
export ADMIN_PASSWORD="yourStrongPassword"
export ALLOWED_ORIGINS="https://your-site.netlify.app"

# Run with screen or systemd
screen -S botnet
uvicorn main:app --host 0.0.0.0 --port 8000

# OR create a systemd service:
cat > /etc/systemd/system/botnet.service << EOF
[Unit]
Description=BOTNET Panel API
After=network.target

[Service]
User=root
WorkingDirectory=/app/botnet
ExecStart=/usr/local/bin/uvicorn main:app --host 0.0.0.0 --port 8000
Restart=always
Environment=API_SECRET_KEY=your-secret-key
Environment=ADMIN_PASSWORD=yourStrongPassword
Environment=ALLOWED_ORIGINS=https://your-site.netlify.app

[Install]
WantedBy=multi-user.target
EOF

systemctl enable botnet
systemctl start botnet
```

---

## 2. Update the Frontend

Open `index.html` and confirm it's deployed on Netlify as-is.
When you log in, enter your backend URL in the **BACKEND API URL** field.
It's saved in localStorage so you only need to enter it once.

---

## 3. Update CORS (Important!)

In your backend environment variables, set:
```
ALLOWED_ORIGINS=https://your-actual-netlify-app.netlify.app
```

Multiple origins (comma-separated):
```
ALLOWED_ORIGINS=https://site1.netlify.app,https://site2.netlify.app,http://localhost:3000
```

---

## 4. Change Default Credentials

**IMPORTANT:** Change the default admin password before deploying!

Set environment variable:
```
ADMIN_PASSWORD=YourVerySecurePassword123!
```

---

## 5. Bot ZIP Structure

When uploading a bot as a ZIP file, the ZIP should contain:

```
mybot.zip
├── main.py          ← auto-detected entry point
├── requirements.txt ← auto-installed on deploy
├── config.py
└── helpers/
    └── utils.py
```

Supported entry point filenames (checked in order):
`main.py`, `bot.py`, `run.py`, `app.py`, `index.py`

Your bot's token is injected as the `BOT_TOKEN` environment variable:
```python
import os
TOKEN = os.environ.get("BOT_TOKEN", "fallback-token")
```

---

## 6. Security Notes

- The `API_SECRET_KEY` is the bearer token used by the frontend
- Store it as an env variable, never hardcode it
- The SQLite DB is stored locally on the server — back it up
- Bot processes run as the same user as the server process
- Max 3 bots enforced by the API

---

## 7. Verify Deployment

```bash
# Check health
curl https://your-api.railway.app/health

# Expected response:
# {"status":"online","version":"3.0"}

# Test login
curl -X POST https://your-api.railway.app/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"yourpassword"}'
```

---

## 8. File Structure

```
botnet-backend/
├── main.py           ← FastAPI app (the backend)
├── requirements.txt  ← Python dependencies
├── Procfile          ← Railway/Heroku start command
├── railway.toml      ← Railway config
├── render.yaml       ← Render config
├── index.html        ← Updated frontend (deploy to Netlify)
├── DEPLOYMENT.md     ← This file
└── bots/             ← Created automatically, stores uploaded bots
    └── bot_abc123/
        ├── main.py
        └── requirements.txt
```
